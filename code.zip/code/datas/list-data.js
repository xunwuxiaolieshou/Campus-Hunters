let list_data = [
  
  {

    date: '小小西电er',
    title: '寻找宝贝柠檬',
    detail_img: '/images/detail/carousel/timg.jpg',
    avatar: '/images/avatar/4.png',
    detail_content: '新买的柠檬于近邻宝领错啦，发现的同学请联系我哦！电话13000000000。请奶茶',
    headImgSrc: '/images/detail/carousel/timg.jpg',
    author: '钢铁侠 ',
    dataTime: '24time',
    detail_love_image1: '/images/icon/chat.png',
    detail_love_image2: '/images/icon/view.png',
    love_count: 88,
    attention_count: 66,
    detail: '钢铁战队。。',
    music: {
      dataUrl: 'http://www.ytmp3.cn/down/54376.mp3', // 音乐链接
      title: '年少有为',   // 音乐标题
      coverImgUrl: '/images/detail/carousel/timg.jpg',
    },
    postId: 0
  },
  {
    
    date: 'may 19 2018',
    title: '寻🐱启示',
    detail_img: '/images/detail/carousel/01.jpg',
    avatar: '/images/avatar/4.png',
    detail_content: '今天我的胖橘走丢了，看到的小可爱请联系qq:23456789。',
    headImgSrc: '/images/detail/carousel/01.jpg',
    author: '美国队长',
    dataTime: '24time',
    detail_love_image1: '/images/icon/chat.png',
    detail_love_image2: '/images/icon/view.png',
    love_count: 88,
    attention_count: 66,
    detail: '有魅力的老男人。',
    music: {
      dataUrl: 'http://www.ytmp3.cn/down/48452.mp3', // 音乐链接
      title: '一路向北',   // 音乐标题
      coverImgUrl: '/images/detail/carousel/01.jpg',
    },
    postId: 1
  },
  {

    date: 'may 19 2018',
    title: '寻找生活物品',
    detail_img: '/images/detail/carousel/03.jpg',
    avatar: '/images/avatar/4.png',
    detail_content: '上午在a楼405丢到了一个耳罩，第一排最左边，联系QQ：1365655689',
    headImgSrc: '/images/detail/carousel/03.jpg',
    author: '绿巨人',
    dataTime: '24time',
    detail_love_image1: '/images/icon/chat.png',
    detail_love_image2: '/images/icon/view.png',
    love_count: 88,
    attention_count: 66,
    detail: '巨无霸教授。',
    music: {
      dataUrl: 'http://www.ytmp3.cn/down/33155.mp3', // 音乐链接
      title: '听海',   // 音乐标题
      coverImgUrl: '/images/detail/carousel/03.jpg',
    },
    postId: 2
  },
  {
    date: '2018/3/15 下午 4:30:35',
    title: '招领启示',
    detail_img: '/images/detail/list/j2.jpg',
    detail_content: '在竹园食堂南门附近的座位下捡到了一些零钱，不知道是哪个小姐姐或小哥哥的，大概有20多，联系我：QQ1589433558',
    detail_love_image1: '/images/icon/chat.png',
    detail_love_image2: '/images/icon/view.png',
    love_count: 92,
    headImgSrc: '/images/detail/list/j2.jpg',
    author: '新华社',
    attention_count: 88,
    avatar: '/images/avatar/1.png',
    music: {
      dataUrl: 'http://up.mcyt.net/down/53810.mp3', // 音乐链接
      title: 'Sunset Jesus-Avicii',   // 音乐标题
      coverImgUrl: '/images/detail/list/j2.jpg',
    },
    postId: 3
  },
  {
    date: '2018/3/17 下午3:30:35',
    title: '招领书',
    detail_img: '/images/detail/list/j3.jpg',
    detail_content: '在c楼328不知道谁丢掉了电路基础的书，鉴于我丢书的经历，帮你拿回来了，联系：QQ2298156485。',
    detail_love_image1: '/images/icon/chat.png',
    detail_love_image2: '/images/icon/view.png',
    love_count: 88,
    attention_count: 66,
    headImgSrc: '/images/detail/list/j3.jpg',
    author: '新华社',
    avatar: '/images/avatar/2.png',
    music: {
      dataUrl: 'http://up.mcyt.net/down/52615.mp3', // 音乐链接
      title: '汪峰 - 儿时',   // 音乐标题
      coverImgUrl: '/images/detail/list/j3.jpg',
    },
    postId: 4
  },
  {

    date: 'sep 19 2016',
    title: '招领书包启示',
    detail_img: '/images/detail/list/j4.jpg',
    avatar: '/images/avatar/1.png',
    detail_content: '在食堂捡到了一个书包，昨天下午就在座位上，今天下午去吃饭的时候发现还是没人拿走，放在失物招领处了，竹园餐厅的。',
    headImgSrc: '/images/detail/list/j4.jpg',
    author: '李白3',
    detail_love_image1: '/images/icon/chat.png',
    detail_love_image2: '/images/icon/view.png',
    love_count: 88,
    attention_count: 66,
    detail: '女神。。。',
    music: {
      dataUrl: 'http://up.mcyt.net/down/46110.mp3', // 音乐链接
      title: '曲婉婷 - 我的歌声里-(电视剧《在线爱》主题曲)',   // 音乐标题
      coverImgUrl: '/images/detail/list/j4.jpg',
    },
    postId: 5
  },
  {

    date: 'sep 19 2016',
    title: '招领u盘',
    detail_img: '/images/detail/list/j6.jpg',
    avatar: '/images/avatar/4.png',
    detail_content: 'E楼205的5-015的座位上有一个u盘，请失主联系我：qq：1489723256',
    headImgSrc: '/images/detail/list/j6.jpg',
    author: '新华社',
    detail_love_image1: '/images/icon/chat.png',
    detail_love_image2: '/images/icon/view.png',
    love_count: 88,
    attention_count: 66,
    detail: '女神2。。。',
    music: {
      dataUrl: 'http://up.mcyt.net/down/52561.mp3', // 音乐链接
      title: 'IF-Ken Arai',   // 音乐标题
      coverImgUrl: '/images/detail/list/j6.jpg',
    },
    postId: 6
  },
];

module.exports = {list_data};