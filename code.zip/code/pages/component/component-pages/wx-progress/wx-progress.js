Page({
  jumpBtn:function(options){
    wx.navigateTo({
      url: '../wx-radio/wx-radio',
      })
  },
  jumpBtn2: function (options) {
    wx.navigateTo({
      url: '../wx-y2/wx-y2',
    })
  }
  
})