Page({
  jumpBtn:function(options){
    wx.navigateTo({
      url: '../wx-silly/wx-silly',
      })
  },
  jumpBtn2: function (options) {
    wx.navigateTo({
      url: '../wx-y3/wx-y3',
    })
  }
  
})