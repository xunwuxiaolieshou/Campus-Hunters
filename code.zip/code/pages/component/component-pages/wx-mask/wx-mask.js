Page({
  jumpBtn: function (options) {
    wx.navigateTo({
      url: '../wx-modal/wx-modal',
    })

  },
  jumpBtn2: function (options) {
    wx.navigateTo({
      url: '../z5/z5',
    })
  }
})
