Page({
  jumpBtn:function(options){
    wx.navigateTo({
      url: '../wx-video/wx-video',
      })
  },
  jumpBtn2: function (options) {
    wx.navigateTo({
      url: '../wx-y6/wx-y6',
    })
  },

})