Page({
  jumpBtn: function (options) {
    wx.navigateTo({
      url: '../wx-picker/wx-picker',
    })

  },
  jumpBtn2: function (options) {
    wx.navigateTo({
      url: '../z6/z6',
    })
  }
})
