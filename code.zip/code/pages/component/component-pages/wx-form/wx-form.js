Page({
  jumpBtn: function (options) {
    wx.navigateTo({
      url: '../wx-icon/wx-icon',
    })

  },
  jumpBtn2: function (options) {
    wx.navigateTo({
      url: '../z3/z3',
    })
  }
})