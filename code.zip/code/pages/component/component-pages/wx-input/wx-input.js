Page({
  jumpBtn: function (options) {
    wx.navigateTo({
      url: '../wx-label/wx-label',
    })

  },
  jumpBtn2: function (options) {
    wx.navigateTo({
      url: '../z4/z4',
    })
  }
})