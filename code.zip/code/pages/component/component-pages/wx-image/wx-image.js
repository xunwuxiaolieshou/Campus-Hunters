Page({
  jumpBtn:function(options){
    wx.navigateTo({
      url: '../wx-text/wx-text',
      })
   },
  jumpBtn2:function(options){
    wx.navigateTo({
      url: '../wx-y1/wx-y1',
    })
  }
})