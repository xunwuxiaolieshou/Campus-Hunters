Page({
  jumpBtn: function (options) {
    wx.navigateTo({
      url: '../wx-audio/wx-audio',
    })
  
  },
    jumpBtn2: function (options) {
    wx.navigateTo({
      url: '../z1/z1',
    })
    }
})