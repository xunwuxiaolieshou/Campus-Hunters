Page({
  jumpBtn:function(options){
    wx.navigateTo({
      url: '../wx-slider/wx-slider',
      })
  },
  jumpBtn2: function (options) {
    wx.navigateTo({
      url: '../wx-y4/wx-y4',
    })
  }
  
})