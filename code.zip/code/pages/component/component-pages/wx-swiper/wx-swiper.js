Page({
  jumpBtn:function(options){
    wx.navigateTo({
      url: '../wx-switch/wx-switch',
      })
  },
  jumpBtn2: function (options) {
    wx.navigateTo({
      url: '../wx-y5/wx-y5',
    })
  }
  
})