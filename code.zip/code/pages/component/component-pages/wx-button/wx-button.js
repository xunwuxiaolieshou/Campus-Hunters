Page({
  jumpBtn: function (options) {
    wx.navigateTo({
      url: '../wx-checkbox/wx-checkbox',
    })

  },
  jumpBtn2: function (options) {
    wx.navigateTo({
      url: '../z2/z2',
    })
  }
})